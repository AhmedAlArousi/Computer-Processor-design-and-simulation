package PipelineRegisters;

public class MEMWB {
	public String ALUResult="";//,ALUResultNew="";
	public String readMemData="";//,readMemDataNew="";
	public int memToReg;//,memToRegNew;
	public int registerWrite;//,registerWriteNew;
	public int rd;//,rdNew;
}
