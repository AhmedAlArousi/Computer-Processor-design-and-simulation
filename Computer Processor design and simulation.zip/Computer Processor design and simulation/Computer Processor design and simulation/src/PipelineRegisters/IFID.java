package PipelineRegisters;

public class IFID {
	public String pc = "";// ,pcNew="";
	public String instr = "";// ,instrNew="";
}
