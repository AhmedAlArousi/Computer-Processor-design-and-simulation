package PipelineRegisters;

public class EXMEM {
	public String ALUResult="";//,ALUResultNew="";
	public String readData2="";//,readData2New="";
	public int MemReg;//,MemRegNew;
	public int RegisterWrite;//,RegisterWriteNew;
	public String branchAddressResult="";//,branchAddressResultNew="";
	public int zeroFlag;//,zeroFlagNew;
	public int memRead;//,memReadNew;
	public int memWrite;//,memWriteNew;
	public int Branch;//,BranchNew;
	public int rd;//,rdNew;
}
