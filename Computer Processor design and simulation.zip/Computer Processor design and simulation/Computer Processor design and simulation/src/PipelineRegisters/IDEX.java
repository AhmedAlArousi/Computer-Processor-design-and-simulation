package PipelineRegisters;

public class IDEX {
	public String readData1 = "";// ,readData1New="";
	public String readData2 = "";// ,readData2New="";
	public String readBranch = "";
	public String signEx = "";// ,signExNew="";
	public String pc = "";// ,pcNew="";
//String reg1="";//,reg1New="";
	public int aluc;// ,alucNew;
	public int branch;// ,branchNew;
	public int ALUSrc;// ,ALUSrcNew;
	public int RegWrite;// ,RegWriteNew;
	public int MemRead;// ,MemReadNew;
	public int MemWrite;// ,MemWriteNew;
	public int MemReg;// ,MemRegNew;
	public int rd;// ,rdNew;
}
